﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net.Http;
using Newtonsoft.Json;

namespace API
{
    public partial class Form1 : Form
    {
        public List<Student> students;
        public string date, base_currency, final_currency;
        public double amount;

        public Form1()
        {
            InitializeComponent();
            students = new List<Student>();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            /*string json = File.ReadAllText("student.json");
            List<Student> students = JsonConvert.DeserializeObject<List<Student>>(json);
            listBox1.Items.Clear();
            foreach (Student student in students)
                listBox1.Items.Add(student.ToString());*/
        }

        public void button1_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            //getResponseAsync();
            string json = File.ReadAllText("student.json");
            //listBox1.Items.Add(json);
            var currencies = JsonConvert.DeserializeObject<Dictionary<string, double>>(json);
            //var currencies = JsonConvert.DeserializeObject<Dictionary<string, string>>("{'key1':'value1','key2':'value2'}");
            //var currencies = JsonConvert.DeserializeObject<Dictionary<string, double>>("{'AED': 3.6731,'AFN': 88.683105}");
            foreach (var record in currencies)
                listBox1.Items.Add(record.ToString());
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            date = textBox2.Text;
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            final_currency = textBox3.Text;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            date = DateTime.Now.ToString("yyyy-MM-dd");
            textBox2.Text = date;
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            Double.TryParse(textBox2.Text, out amount);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            base_currency = textBox1.Text;
        }

        /*public async Task<string> getResponseAsync()
        {
            HttpClient client = new HttpClient();
            string call = "http://radoslaw.idzikowski.staff.iiar.pwr.wroc.pl/instruction/students.json";
            //string call = "https://free.currconv.com/api/v7/convert?q=" + base_currency + "_" + final_currency + "," + final_currency + "_" + base_currency +"&compact=ultra&date=" + date + "&apiKey=6e518d133c379bc395df";
            string response = await client.GetStringAsync(call);
            students = JsonConvert.DeserializeObject<List<Student>>(response);
            return response;
        }*/

    }
}
